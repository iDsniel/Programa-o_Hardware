var searchData=
[
  ['pino1_0',['pino1',['../struct_ent___usuario.html#abea5b120022f496fb1fb4591a5f6a7b9',1,'Ent_Usuario']]],
  ['pino2_1',['pino2',['../struct_ent___usuario.html#adee805408b31436178a773d0dc8f56b1',1,'Ent_Usuario']]],
  ['porta1_2',['porta1',['../struct_ent___usuario.html#a29c0f12f37615a4d41171c59696d524e',1,'Ent_Usuario']]],
  ['porta2_3',['porta2',['../struct_ent___usuario.html#aa25279c2e75a6f22b872f014b0f378f7',1,'Ent_Usuario']]]
];
