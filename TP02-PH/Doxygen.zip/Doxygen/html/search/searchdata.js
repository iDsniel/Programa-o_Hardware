var indexSectionsWithContent =
{
  0: "ep",
  1: "e",
  2: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Variables"
};

